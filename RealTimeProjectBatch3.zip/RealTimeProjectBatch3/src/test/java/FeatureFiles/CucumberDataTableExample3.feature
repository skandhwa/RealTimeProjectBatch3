Feature: Implementing Cucumber Data Table

  Scenario: Cucumber Data Table Implementation
    Given user opens the registration form
    And user enters the below details
      | firstName | lastName | address    | emailAddress   |
      | Tom       | Banton   | Manchester | abcd@gmail.com |
