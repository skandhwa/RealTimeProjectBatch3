@sanity

Feature: Validate Ecommerce functionality

  Background: 
    Given user opens the browser url
    And user enters the username as "abcd"
    And user enters the password as "efgh"
    When user clicks on login button
    Then user will be navigated to homepage of application

  Scenario: Validate search electronic product functionality
    And user will search electronic product
    And user will add it to cart

  Scenario: Validate search lifestyle product functionality
    And user will search lifestyle product
    And user will add it to cart

  Scenario: Validate search clothing product functionality
    And user will search clothing product
    And user will add it to cart
