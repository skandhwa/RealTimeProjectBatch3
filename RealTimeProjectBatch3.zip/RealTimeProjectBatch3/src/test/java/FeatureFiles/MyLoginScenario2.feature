Feature: Login scenario with multiple credentials

@smoke
  Scenario Outline: Validate Login scenario with multiple correct credentials
    Given user opens the browser URL
    And user enters the username as "<username>"
    And user enters the password as "<password>"
    When user clicks on login button
    Then user will be navigated to homepage

    Examples: 
      | username | password  |
      | abcd     | test@1234 |
      | efgh     | test@5678 |
      | fhjk     | test@8934 |

@sanity
  Scenario Outline: Validate Login scenario with multiple incorrect credentials
    Given user opens the browser URL
    And user enters the username as "<username>"
    And user enters the password as "<password>"
    When user clicks on login button
    But an error message is thrown that user credentials are wrong

    Examples: 
      | username | password  |
      | abcr     | test@1234 |
      | efgf     | test@5678 |
      | fhjh     | test@8934 |
