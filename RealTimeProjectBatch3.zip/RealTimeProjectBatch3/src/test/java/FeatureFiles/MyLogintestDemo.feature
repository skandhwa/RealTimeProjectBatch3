Feature: Login Scenario Testing

@regression
  Scenario: Validate Login functionality with correct credentials
    Given user opens the browser URL
    And user enters the username 
    And user enters the password
    When user clicks on login button
    Then user will be navigated to homepage
    #And validate that navigation is successfull
