package StepDefinition10;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition10 {
	
	WebDriver driver;
	
	
	@Before(order=1)
	public void beforeTest1()
	{
		System.out.println("I will run before every scenario test1");
	}
	
	@Before(order=2)
	public void beforeTest2()
	{
		System.out.println("I will run before every scenario test2");
	}
	
	@After(order=1)
	public void afterTest1()
	{
		System.out.println("I will run after every scenario test1");
	}
	
	@After(order=2)
	public void afterTest2()
	{
		System.out.println("I will run after every scenario test2");
	}
	
	@Before("@sanity")
	public void beforeSanity()
	{
		System.out.println("This is before sanity only ");
	}
	
	@After("@sanity")
	public void afterSanity()
	{
		System.out.println("This is after sanity only ");
	}
	
	
	
	
	@Given("user opens the browser URL")
	public void user_opens_the_browser_url() {
	   
		
		System.out.println("Browser opened");
	}

	@Given("user enters the username")
	public void user_enters_the_username() {
	    
		System.out.println("username entered");
	}

	@Given("user enters the password")
	public void user_enters_the_password() {
		
		System.out.println("password entered");
		
	    
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
	    
		System.out.println("Login button clicked");
	}

	@Then("user will be navigated to homepage")
	public void user_will_be_navigated_to_homepage() {
		
		System.out.println("navigation to homepage successfull");
	    
	}
	
	@Given("user enters the username as {string}")
	public void user_enters_the_username_as(String string) {
	    
	}

	@Given("user enters the password as {string}")
	public void user_enters_the_password_as(String string) {
	    
	}
	
	

@When("an error message is thrown that user credentials are wrong")
public void an_error_message_is_thrown_that_user_credentials_are_wrong() {
    
}


@Given("user opens the browser url")
public void user_opens_the_browser_url1() {
    
}

@Then("user will be navigated to homepage of application")
public void user_will_be_navigated_to_homepage_of_application() {
    
}

@Then("user will search electronic product")
public void user_will_search_electronic_product() {
   
}

@Then("user will add it to cart")
public void user_will_add_it_to_cart() {
   
}

@Then("user will be nvaigated to homepage of application")
public void user_will_be_nvaigated_to_homepage_of_application() {
   
}

@Then("user will search lifestyle product")
public void user_will_search_lifestyle_product() {
   
}

@Then("user will search clothing product")
public void user_will_search_clothing_product() {
    
}


@Given("user opens the registration form")
public void user_opens_the_registration_form() {
	
	driver=new ChromeDriver();
	driver.get("https://demo.automationtesting.in/Register.html");
	driver.manage().window().maximize();
   
}

@Given("user enters the below details")
public void user_enters_the_below_details(io.cucumber.datatable.DataTable userdata) {
	
	List<List<String>> data= userdata.asLists(String.class);
	driver.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys(data.get(1).get(0));
	driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(data.get(1).get(1));
	driver.findElement(By.xpath("//textarea[@rows='3']")).sendKeys(data.get(1).get(2));
	driver.findElement(By.xpath("//*[@type='email']")).sendKeys(data.get(1).get(3));
	
	
    
}


	
	
	
	
	
	
	
	
	
	
	

}
