package StepDefinition20;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition20 {
	
	
	@Given("user opens the homepage of the application")
	public void user_opens_the_homepage_of_the_application() {
	   
	}

	@Given("user enters the username as {string}")
	public void user_enters_the_username_as(String string) {
	   
	}

	@Given("user enters password as {string}")
	public void user_enters_password_as(String string) {
	   
	}

	@When("user clicks on login button")
	public void user_clicks_on_login_button() {
	    
	}

	@Then("validate user will be navigated to homepage")
	public void validate_user_will_be_navigated_to_homepage() {
	   
	}

}
