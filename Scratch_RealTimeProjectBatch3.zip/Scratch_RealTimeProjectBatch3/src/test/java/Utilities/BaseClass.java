package Utilities;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BaseClass {
	
	static String browserName;
	public static WebDriver driver;
	
	public static WebDriver initializeDriver() throws IOException
	{
		browserName= FetchDataFromProperty.getDataFromProperty().getProperty("browser");
		if(browserName.equalsIgnoreCase("chrome"))
		{
			driver=new ChromeDriver();
			driver.get(FetchDataFromExcel.getDataFromExcel(1, 0));
			driver.manage().window().maximize();
			
		}
		
		if(browserName.equalsIgnoreCase("firefox"))
		{
			driver=new FirefoxDriver();
			driver.get(FetchDataFromExcel.getDataFromExcel(1, 0));
			driver.manage().window().maximize();
			
		}
		
		if(browserName.equalsIgnoreCase("edge"))
		{
			driver=new EdgeDriver();
			driver.get(FetchDataFromExcel.getDataFromExcel(1, 0));
			driver.manage().window().maximize();
			
		}
		
		
		return driver;
		
	}
	
	
	public static void scrollDown()
	{
		
	}
	
	public static void addExplicitWait()
	{
		
	}
	
	public static void getTitle()
	{
		
	}
	
	public static void switchWindow()
	{
		
	}
	
	
	
	
	

}
